const express = require('express');
const { protect } = require('../middlewares/authMiddleware');
const allowRoles = require('../middlewares/roleMiddleware');

const router = express.Router();

router.get('/admin', protect, allowRoles('Admin'), (req, res) => {
    res.status(200).json({ message: 'Welcome Admin!' });
});

router.get('/user', protect, allowRoles('User'), (req, res) => {
    res.status(200).json({ message: 'Welcome User!' });
});

module.exports = router;
