const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db'); // Ensure db.js exists in the config folder

const app = express();
dotenv.config();

connectDB();

app.use(express.json());

// Importing routes
const userRoutes = require('./routes/userRoutes'); // Ensure userRoutes.js exists in routes
app.use('/api/users', userRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
